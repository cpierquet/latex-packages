wordle is a package to work with Wordle game.
-----------------------------------------------------------
wordle est un package pour travailler avec le jeu du sutom.
-----------------------------------------------------------
Author : Cédric Pierquet
email : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt
Source : https://tex.stackexchange.com/questions/659860/wordle-like-colored-letter-boxes-in-latex