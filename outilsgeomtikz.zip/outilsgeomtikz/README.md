OutilsGeomTikz is a package with geometric tools in TikZ.
-----------------------------------------------------------
OutilsGeomTikz est un package avec outils géométriques en TikZ.
-----------------------------------------------------------
Author : Cédric Pierquet
email : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt