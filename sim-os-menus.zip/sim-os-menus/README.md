sim-os-menus is a package to present a window/context menu/terminal like in an OS
-------------------------------------------------------------------------------------------------------
sim-os-menus est un pakage pour afficher une fenêtre, un terminal, un menu contextuel comme dans un OS.
-------------------------------------------------------------------------------------------------------
Author  : Cédric Pierquet
email   : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt