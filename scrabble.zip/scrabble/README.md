Scrabble is a package to work with the Scrabble Board Game, simple or with words.
-------------------------------------------------------------------------------------
Scrabble est un package pour représenter un plateau de Scrabble, avec mots éventuels.
-------------------------------------------------------------------------------------
Author : Cédric Pierquet
email : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt
Inspiration : Mark Wibrow in https://tex.stackexchange.com/questions/194780/tikz-drawing-a-rectangle-with-spikes-on-borders
Scrabble is a Trademark from Hasbro and Mattel