FenetreCas is a package with Xcas or Geogebra CAS Window-like.
----------------------------------------------------------------------
FenetreCas est un package avec des fenêtres CAS type Geogebra ou Xcas.
----------------------------------------------------------------------
Author : Cédric Pierquet
email : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt