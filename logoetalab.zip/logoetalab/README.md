logoetalab is a package with french licence etalab 2.0 logo.
----------------------------------------------------------------
logoetalab est un package avec le logo de la licence etalab 2.0.
----------------------------------------------------------------
Author.......: Cédric Pierquet
email........: cpierquet@outlook.fr
Licence......: Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt
Licence svg..: CC-BY 2.0