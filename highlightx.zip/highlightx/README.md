highlightx is a package to highlight paragraphs or formulas.
-------------------------------------------------------------------------
highlightx est un package pour surligner des paragraphes ou des formules.
-------------------------------------------------------------------------
Author  : Cédric Pierquet
Code    : Antal Spector-Zabusky (for hightlighting paragraphs)
email   : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt