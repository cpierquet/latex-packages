customenvs is a package with some classics custom environments.
----------------------------------------------------------------------
customenvs est un package avec environnements classiques personnalisés.
----------------------------------------------------------------------
Author....: Cédric Pierquet
email.....: cpierquet@outlook.fr
Licence...: Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt
Source....: CC-BY-SA 4.0 https://tex.stackexchange.com/questions/504092/replicating-a-fancy-bordered-text-style-in-latex/504145#504145