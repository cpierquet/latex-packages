euromoney is a package with euro coins and banknotes.
-----------------------------------------------------
Author..: Cédric Pierquet
email...: cpierquet@outlook.fr
Licence.: Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt
........: pdf converted from domain public svg (user frankes in openclipart), see https://openclipart.org/artist/frankes