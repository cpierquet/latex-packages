TriviaPursuit is a package to work with the Trivial Pursuit Board Game.
----------------------------------------------------------------------------
TriviaPursuit est un package pour représenter un plateau de Trivial Pursuit.
----------------------------------------------------------------------------
Author : Cédric Pierquet
email : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt
Trivial Pursuit is a Trademark from Hasbro