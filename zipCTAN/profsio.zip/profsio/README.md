ProfSio is a package for teachers in french BTS SIO's Math.
----------------------------------------------------------------
ProfSio est un package pour les enseignants de Maths en BTS SIO.
----------------------------------------------------------------
Author.......: Cédric Pierquet
email........: cpierquet@outlook.fr
Licence......: Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt