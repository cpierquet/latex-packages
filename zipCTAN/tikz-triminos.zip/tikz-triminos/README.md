This package provides a macro to obtain triminos, made with TikZ.  
-----------------------------------------------------------------  
Author.........: Cédric Pierquet  
email..........: cpierquet@outlook.fr  
Licences.......: Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt  
Inspiration....: https://schule.paul-matthies.de/Trimino.php (CC BY-NC-SA 4.0)