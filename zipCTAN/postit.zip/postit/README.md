postit is a package to work with post-it with [fr] or [en] syntax.
---------------------------------------------------------------------------------
postit est un package pour travailler des post-it avec commandes en [fr] ou [en].
---------------------------------------------------------------------------------
Author : Cédric Pierquet
email : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt