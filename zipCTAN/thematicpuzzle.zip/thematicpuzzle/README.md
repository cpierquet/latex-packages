thematicpuzzle is a package to present a 'puzzle' of different themes.
------------------------------------------------------------------------------
thematicpuzzle est un package pour présenter un 'puzzle' de différents thèmes.
------------------------------------------------------------------------------
Author  : Cédric Pierquet
email   : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt