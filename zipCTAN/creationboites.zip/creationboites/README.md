CreationBoites is a package for creating and personnalize tcbox with macros.
---------------------------------------------------------------------------------
CreationBoites est un package pour créer des boîtes tcbox avec personnalisations.
---------------------------------------------------------------------------------
Author : Cédric Pierquet
email : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt