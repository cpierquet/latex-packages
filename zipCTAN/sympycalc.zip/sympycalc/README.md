SympyCalc is a package to work with Sympy (Python) with TeX printing.
-----------------------------------------------------------------------------
SympyCalc un package pour travailler avec le module Sympy et sa sortie LaTeX.
-----------------------------------------------------------------------------
Author : Cédric Pierquet
email : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt
Note : SymPy is a Python library for symbolic math (sympy.org).