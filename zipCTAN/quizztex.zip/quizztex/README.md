QuizzTex is a package to create quizzes with 'Who Wants to Be a Millionaire ?' design for example.
----------------------------------------------------------------------------------------------------------------
QuizzTex est un package pour présenter des quizzes à la manière de 'Qui veut gagner des Millions ?' par exemple.
----------------------------------------------------------------------------------------------------------------
Author.......: Cédric Pierquet
email........: cpierquet@outlook.fr
Licence......: Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt
               'Who Wants to Be a Millionaire ?' is a Trademark from Sony Pictures Television.
			   'Tout le monde veut prendre sa place' is a Tradematk from Air Productions