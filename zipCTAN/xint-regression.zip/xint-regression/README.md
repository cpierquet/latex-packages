xint-regression is a package to work with classic regressions, with xint.
-----------------------------------------------------------------------------------------
xint-regression est un package pour travailler avec des régressions classiques, avec xint.
------------------------------------------------------------------------------------------
Author.......: Cédric Pierquet
email........: cpierquet@outlook.fr
Licence......: Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt