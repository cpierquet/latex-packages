This package provides some macros to present simple decoration fonts, made with TikZ.
Available decorations are brushpaint and inkline, and gridlcd.
-------------------------------------------------------------------------------------
Author...: Cédric Pierquet
email....: cpierquet@outlook.fr
Licences.: Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt
           CC BY-SA 4.0 (https://tex.stackexchange.com/questions/475141/simulating-paintbrush-strokes-in-tikz from user121799)
           CC BY-SA 4.0 (https://tex.stackexchange.com/questions/460836/custom-line-cap-to-simulate-inked-line-in-tikz/460842#460842 from user121799)