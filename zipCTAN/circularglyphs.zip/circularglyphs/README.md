circularglyphs is a package with circular glyphs alphabet.
-----------------------------------------------------------
circularglyphs est un package sur l'alphabet CircularGlyph.
-----------------------------------------------------------
Author  : Cédric Pierquet
email   : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt
Thanks  : Irolan, in https://www.deviantart.com/irolan/art/Circular-Glyphs-479352599