tikz3d-fr is a package to work with some 3D figures.
----------------------------------------------------------
tikz3d-fr est un package pour travailler un peu en tikz3d.
----------------------------------------------------------
Author : Cédric Pierquet
email : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt