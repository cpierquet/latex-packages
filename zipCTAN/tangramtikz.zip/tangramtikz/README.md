TangramTikz is a package to work with Tangram Puzzle.
--------------------------------------------------------------------
TangramTikz est un package travailler avec le jeu de Puzzle Tangram.
--------------------------------------------------------------------
Author : Cédric Pierquet
email : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt