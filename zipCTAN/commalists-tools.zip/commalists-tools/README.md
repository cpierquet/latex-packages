This package provides some macros for manipulating numeral comma separated lists.
Available tools are adding, removing, counting, testing, reversing, sorting, etc
---------------------------------------------------------------------------------
Author..: Cédric Pierquet
email...: cpierquet@outlook.fr
Licence.: Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt