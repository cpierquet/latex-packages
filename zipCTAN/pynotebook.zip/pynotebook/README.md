pynotebook is a package to present (raw, markdown or python) codes (and execution with lualatex) as in a jupyter notebook.
--------------------------------------------------------------------------------------------------------------------------

Author....: Cédric Pierquet
email.....: cpierquet@outlook.fr
Licence...: Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt
