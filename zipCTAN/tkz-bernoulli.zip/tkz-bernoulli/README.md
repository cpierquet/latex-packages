tkz-bernoulli is a package to present Bernoulli trees with tikz.
-----------------------------------------------------------------------------
tkz-bernoulli est un package pour représenter un arbre de Bernoulli avec tikz.
-----------------------------------------------------------------------------
Author  : Cédric Pierquet
email   : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt