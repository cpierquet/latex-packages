ipsum is a package to work with multilingual 'dummy texts'.
----------------------------------------------------------------------------
ipsum est un pakage pour afficher des paragraphes multilangues type "dummy".
----------------------------------------------------------------------------
Author : Cédric Pierquet
email : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt