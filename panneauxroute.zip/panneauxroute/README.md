PanneauxRoute is a package to display french road signs.
----------------------------------------------------------------------------------------------------
PanneauxRoute est un package pour afficher des panneaux de signalisation routière (format vectoriel).
-----------------------------------------------------------------------------------------------------
Author.......: Cédric Pierquet
email........: cpierquet@outlook.fr
Licence......: Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt
Sources......: https://www.geoinformations.developpement-durable.gouv.fr/panneaux-routiers-au-format-svg-et-png-par-a2688.html
.............: http://sig974.free.fr/?p=1520
Licence img..: CC BY-SA 3.0 
