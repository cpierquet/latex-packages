This package (like luarandom, but without the obligation to use lualatex) provides some macros for creating random integer number lists between a and b.
This list can have multiple numbers or not, and this list can be sorted or not.
--------------------------------------------------------------------------------------------------------------------------------------------------------
Author..: Cédric Pierquet
email...: cpierquet@outlook.fr
Licence.: Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt