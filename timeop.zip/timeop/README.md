Calculates and displays arithmetic operations with durations.

-------------------------------------------------------------

Author..: Cédric Pierquet

email...: cpierquet@outlook.fr

Licence.: Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt