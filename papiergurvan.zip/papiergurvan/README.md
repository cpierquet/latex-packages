PapierGurvan is a package to work with Gurvan grid papers.
----------------------------------------------------------------------------
PapierGurvan est un package pour travailler avec des papiers de type Gurvan.
----------------------------------------------------------------------------
Author of the package  : Cédric Pierquet
Author of the paper    : http://www.sos-ecriture.fr/2014/10/papier-gurvan.html
email                  : cpierquet@outlook.fr
Licence                : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt