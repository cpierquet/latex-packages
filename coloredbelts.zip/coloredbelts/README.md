coloredbelts is a package with colored judo's belts.
-----------------------------------------------------------------
coloredbelts est un package avec des ceintures de judo, colorées.
-----------------------------------------------------------------
Author.......: Cédric Pierquet
email........: cpierquet@outlook.fr
Licence......: Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt
Licence svg  : CC BY-SA 3.0 https://commons.wikimedia.org/wiki/File:Judo_yellow_belt.svg