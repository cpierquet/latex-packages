PixelArtTikz is a package to work with PixlArts.
---------------------------------------------------------------
PixelArtTikz est un package pour travailler avec des PixelArts.
---------------------------------------------------------------
Author : Cédric Pierquet
email : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt