ResolSysteme is a package to work with Linear Systems and matrix.
----------------------------------------------------------------------------------------
ResolSysteme est un package pour travailler avec des systèmes linéaires et des matrices.
----------------------------------------------------------------------------------------
Author : Cédric Pierquet
email : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt