WriteOnGrid is a package to work with a grid, with text on the lines.
-----------------------------------------------------------------------
WriteOnGrid est un package pour écrire sur les lignes d'un quadrillage.
-----------------------------------------------------------------------
Author : Cédric Pierquet
email : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt