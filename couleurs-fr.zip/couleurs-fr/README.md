couleurs-fr is a package with french names of xcolor schemes.
---------------------------------------------------------------------------
couleurs-fr est un package avec les versions francisées de couleurs xcolor.
---------------------------------------------------------------------------
Author : Cédric Pierquet
email : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt