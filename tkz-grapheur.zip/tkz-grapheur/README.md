tkz-grapheur is a package to work with curves, with TikZ.
--------------------------------------------------------------------------------
tkz-grapheur un package spécifique pour travailler avec des courbes, en TikZ.
--------------------------------------------------------------------------------
Author  : Cédric Pierquet
email   : cpierquet@outlook.fr
Licence : Released under the LaTeX Project Public License v1.3c or later, see http://www.latex-project.org/lppl.txt